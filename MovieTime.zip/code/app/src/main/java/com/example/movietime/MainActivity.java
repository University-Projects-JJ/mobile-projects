package com.example.movietime;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.movietime.Adapters.CaptionedImageAdapter;
import com.example.movietime.Fragments.ExploreFragment;
import com.example.movietime.Fragments.FavoritesFragment;
import com.example.movietime.Fragments.MovieDetailsFragment;
import com.example.movietime.Fragments.MoviesFragment;
import com.example.movietime.Fragments.ProfileFragment;
import com.example.movietime.Models.Movie;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements CaptionedImageAdapter.onCaptionedImageClickListener {
	Toolbar appBar;
	Button appBarSearch;
	Button appBarBack;
	Button appBarEdit;
	BottomNavigationView bottomNavigationView;
	boolean isMovieFragment = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		this.appBar = (Toolbar) findViewById(R.id.appBar);
		setSupportActionBar(appBar);
		Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(false);
		
		
		appBarBack = findViewById(R.id.btnAppBarBack);
		appBarSearch = findViewById(R.id.btnAppBarSearch);
		appBarEdit = findViewById(R.id.btnAppBarEdit);
		
		appBarBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				getSupportFragmentManager().popBackStack();
				appBarBack.setVisibility(View.GONE);
			}
		});
		
		bottomNavigationView = findViewById(R.id.navBar);
		setUpBottomNavigationView();
		
		
	}
	
	
	private void setUpBottomNavigationView() {
		bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(@NonNull MenuItem item) {
				Fragment switchTo = null;
				isMovieFragment = false;
				
				if (item.getItemId() == R.id.nav_explore) {
					switchTo = new ExploreFragment();
					appBarSearch.setVisibility(View.VISIBLE);
					appBarBack.setVisibility(View.GONE);
					appBarEdit.setVisibility(View.GONE);
				}
				
				else if (item.getItemId() == R.id.nav_favorites) {
					switchTo = new FavoritesFragment();
					appBarSearch.setVisibility(View.VISIBLE);
					appBarBack.setVisibility(View.GONE);
					appBarEdit.setVisibility(View.GONE);
				}
				
				else if (item.getItemId() == R.id.nav_profile) {
					switchTo = new ProfileFragment();
					appBarEdit.setVisibility(View.VISIBLE);
					appBarSearch.setVisibility(View.GONE);
					appBarBack.setVisibility(View.GONE);
				}
				
				//else if movie details or search fragment
				else {
					switchTo = new MoviesFragment();
					appBarSearch.setVisibility(View.VISIBLE);
					appBarBack.setVisibility(View.GONE);
					appBarEdit.setVisibility(View.GONE);
				}
				
				
				// set fragment
				getSupportFragmentManager()
					.beginTransaction()
					.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
					.addToBackStack(null)
					.replace(R.id.fragmentContainer, switchTo)
					.commit();
				
				return true;
			}
		});
		bottomNavigationView.setSelectedItemId(R.id.nav_home);
		bottomNavigationView.setOnNavigationItemReselectedListener(new BottomNavigationView.OnNavigationItemReselectedListener() {
			@Override
			public void onNavigationItemReselected(@NonNull MenuItem item) {
				if (isMovieFragment) {
					getSupportFragmentManager().popBackStack();
					appBarBack.setVisibility(View.GONE);
					isMovieFragment = false;
				}
			}
		});
		
		
	}
	
	
	
	@Override
	public void onCaptionedImageClick(int position) {
		isMovieFragment = true;
		
		appBarSearch.setVisibility(View.VISIBLE);
		appBarBack.setVisibility(View.VISIBLE);
		appBarEdit.setVisibility(View.GONE);
		MovieDetailsFragment movieDetailsFragment = new MovieDetailsFragment(Movie.MOVIES[position], this);
		
		getSupportFragmentManager()
			.beginTransaction()
			.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
			.addToBackStack(null)
			.replace(R.id.fragmentContainer, movieDetailsFragment)
			.commit();
	}
}