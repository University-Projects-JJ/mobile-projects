package com.example.movietime.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.movietime.Adapters.CaptionedImageAdapter;
import com.example.movietime.Models.CaptionedImage;
import com.example.movietime.Models.Movie;
import com.example.movietime.R;

public class ProfileFragment extends Fragment {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
													 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view = inflater.inflate(R.layout.fragment_profile, container, false);
		// setHasOptionsMenu(true);
		setUpScrollableAdapters(view);
		return view;
	}
	
	private void setUpScrollableAdapters(View view) {
		CaptionedImage[] captionedImages = CaptionedImage.captionedImageArrayFromMovie(Movie.MOVIES);
		RecyclerView rvWatched = (RecyclerView) view.findViewById(R.id.rvWatched);
		rvWatched.setAdapter(
			new CaptionedImageAdapter(captionedImages, R.layout.card_movie_simple_poster, (CaptionedImageAdapter.onCaptionedImageClickListener) getActivity(), null)
		);
		rvWatched.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false)
		);
	}
	
	// @Override
	// public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
	// 	inflater.inflate(R.menu.menu_action_bar_edit, menu);
	// 	super.onCreateOptionsMenu(menu, inflater);
	// }
}