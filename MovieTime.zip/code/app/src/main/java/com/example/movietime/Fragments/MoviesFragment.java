package com.example.movietime.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movietime.Adapters.CaptionedImageAdapter;
import com.example.movietime.Models.CaptionedImage;
import com.example.movietime.Models.Movie;
import com.example.movietime.R;


public class MoviesFragment extends Fragment {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
													 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view = inflater.inflate(R.layout.fragment_movies, container, false);
		
		setUpScrollableAdapters(view);
		// setHasOptionsMenu(true);
		return view;
	}
	
	// @Override
	// public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
	// 	inflater.inflate(R.menu.menu_action_bar_search, menu);
	// 	super.onCreateOptionsMenu(menu, inflater);
	// }
	
	private void setUpScrollableAdapters(View view){
		CaptionedImage[] captionedImages = CaptionedImage.captionedImageArrayFromMovie(Movie.MOVIES);
		RecyclerView rvNewMovies = (RecyclerView) view.findViewById(R.id.rvNewMovies);
		rvNewMovies.setAdapter(
			new CaptionedImageAdapter(captionedImages, R.layout.card_simple_poster_caption, (CaptionedImageAdapter.onCaptionedImageClickListener) getActivity(), null)
		);
		rvNewMovies.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false)
		);
		
		// TODO select only popular movies
		RecyclerView	rvPopular = (RecyclerView) view.findViewById(R.id.rvPopular);
		rvPopular.setAdapter(
			new CaptionedImageAdapter(captionedImages, R.layout.card_simple_poster_caption, (CaptionedImageAdapter.onCaptionedImageClickListener) getActivity(),null)
		);
		rvPopular.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false)
		);
		
		// TODO select only coming soon movies
		RecyclerView rvComingSoon = (RecyclerView) view.findViewById(R.id.rvComingSoon);
		rvComingSoon.setAdapter(
			new CaptionedImageAdapter(captionedImages, R.layout.card_simple_poster_caption, (CaptionedImageAdapter.onCaptionedImageClickListener) getActivity(), null)
		);
		
		rvComingSoon.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false)
		);
	}
}