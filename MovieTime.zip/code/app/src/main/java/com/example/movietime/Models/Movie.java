package com.example.movietime.Models;

import com.example.movietime.R;

import java.util.ArrayList;

public class Movie {
	
	public String
		title,
		desc,
		cast,
		characters,
		duration,
		year;
	
	public double rating;
	
	public int poster;
	public int[] castImages;
	
	
	public boolean isNew;
	
	public static Movie[] MOVIES = {
		
		new Movie(
			"Interstellar",
			"A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
			"2014",
			R.drawable.movie_interstellar,
			169,
			8.6,
			"Matthew McConaughey,Anne Hathaway,Mackenzie Foy,John Lithgow,Timothée Chalamet",
			new int[]{R.drawable.matthew_mcconaughey,R.drawable.anne_hathaway,R.drawable.mackenzie_foy,R.drawable.john_lithgow,R.drawable.timothee_chalamet},
			"Cooper,Brand,Murph (young),Donald,Tom (young)",
			false
		),
		
		new Movie(
			"John Wick",
			"An ex-hit-man comes out of retirement to track down the gangsters that killed his dog and took everything from him.",
			"2014",
			R.drawable.movie_john_wick,
			101,
			7.4,
			"Keanu Reeves,Michael Nyqvist,Alfie Allen",
			new int[]{R.drawable.matthew_mcconaughey,R.drawable.anne_hathaway,R.drawable.mackenzie_foy,R.drawable.john_lithgow,R.drawable.timothee_chalamet},
			"John Wick,Viggo Tarasov,Iosef Tarasov",
			false
		),
		
		new Movie(
			"John Wick: Chapter 3 - Parabellum",
			"John Wick is on the run after killing a member of the international " +
				"assassins' guild, and with a $14 million price tag on his head, " +
				"he is the target of hit men and women everywhere.",
			"2019",
			R.drawable.movie_john_wick_3,
			170,
			7.4,
			"Keanu Reeves,Halle Berry,Ian McShane",
			new int[]{R.drawable.matthew_mcconaughey,R.drawable.anne_hathaway,R.drawable.mackenzie_foy,R.drawable.john_lithgow,R.drawable.timothee_chalamet},
			"John Wick,Sofia,Winston",
			true
		),
		
		new Movie(
			"John Wick: Chapter 2",
			"After returning to the criminal underworld to repay a debt, John Wick discovers that a large bounty has been put on his life.",
			"2017",
			R.drawable.movie_john_wick_2,
			122,
			7.5,
			"Keanu Reeves,Riccardo Scamarcio,Ian McShane",
			new int[]{R.drawable.matthew_mcconaughey,R.drawable.anne_hathaway,R.drawable.mackenzie_foy,R.drawable.john_lithgow,R.drawable.timothee_chalamet},
			"John Wick,Santino D'Antonio,Winston",
			false
		),
		
		new Movie(
			"Scream 2",
			"Two years after the first series of murders, as Sidney acclimates to college life, " +
				"someone donning the Ghostface costume begins a new string of killings.",
			"1997",
			R.drawable.movie_scream_2,
			120,
			6.2,
			"Neve Campbell,Courteney Cox,David Arquette",
			new int[]{R.drawable.matthew_mcconaughey,R.drawable.anne_hathaway,R.drawable.mackenzie_foy,R.drawable.john_lithgow,R.drawable.timothee_chalamet},
			"Sidney Prescott,Gale Weathers,Dewey Riley",
			false
		),
		
		new Movie(
			"The Polar Express",
			"On Christmas Eve, a young boy embarks on a magical adventure to the North Pole on the Polar Express," +
				" while learning about friendship, bravery, and the spirit of Christmas.",
			"2004",
			R.drawable.movie_the_polar_express,
			100,
			6.6,
			"Tom Hanks,Chris Coppola,Michael Jeter",
			new int[]{R.drawable.matthew_mcconaughey,R.drawable.anne_hathaway,R.drawable.mackenzie_foy,R.drawable.john_lithgow,R.drawable.timothee_chalamet},
			"Conductor,Toothless Boy,Smokey",
			false
		),
		
	};
	
	public Movie(
		String title, String desc, String year,
		int poster, int duration,
		double rating,
		String cast, int[] castImages, String characters,
		boolean isNew) {
		
		this.title = title;
		this.desc = desc;
		this.year = year;
		
		this.poster = poster;
		setDuration(duration);
		this.rating = rating;
		
		this.cast = cast;
		this.castImages = castImages;
		this.characters = characters;
		this.isNew = isNew;
	}
	
	public void setDuration(int duration) {
		this.duration = duration + " mins";
	}
}
