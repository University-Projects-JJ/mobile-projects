package com.example.movietime.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movietime.Adapters.CategoryAdapter;
import com.example.movietime.Adapters.MovieDetailedAdapter;
import com.example.movietime.Adapters.CaptionedImageAdapter;
import com.example.movietime.Models.CaptionedImage;
import com.example.movietime.Models.Category;
import com.example.movietime.Models.Movie;
import com.example.movietime.R;

public class ExploreFragment extends Fragment {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
													 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view = inflater.inflate(R.layout.fragment_explore, container, false);
		
		setUpScrollableAdapters(view);
		// setHasOptionsMenu(true);
		
		return view;
	}
	
	// @Override
	// public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
	// 	inflater.inflate(R.menu.menu_action_bar_search, menu);
	// 	super.onCreateOptionsMenu(menu, inflater);
	// }
	
	private void setUpScrollableAdapters(View view) {
		CaptionedImage[] captionedImages = CaptionedImage.captionedImageArrayFromMovie(Movie.MOVIES);
		
		RecyclerView rvCategories = view.findViewById(R.id.rvFavorites);
		rvCategories.setAdapter(
			new CategoryAdapter(Category.CATEGORIES)
		);
		rvCategories.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false)
		);
		
		RecyclerView rvRecommended = view.findViewById(R.id.rvRecommended);
		rvRecommended.setAdapter(
			new CaptionedImageAdapter(captionedImages, R.layout.card_simple_poster_caption, (CaptionedImageAdapter.onCaptionedImageClickListener) getActivity(), null)
		);
		rvRecommended.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false)
		);
		
		RecyclerView rvTrending = view.findViewById(R.id.rvTrending);
		rvTrending.setAdapter(
			new MovieDetailedAdapter(Movie.MOVIES)
		);
		rvTrending.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false)
		);
	}
	
	
}