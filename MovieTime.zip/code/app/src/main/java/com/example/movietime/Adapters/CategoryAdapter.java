package com.example.movietime.Adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movietime.Models.Category;
import com.example.movietime.R;


public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {
	
	public static final class ViewHolder extends RecyclerView.ViewHolder {
		private CardView cardView;
		
		public ViewHolder(CardView cv) {
			super(cv);
			cardView = cv;
			
			// cv.setOnClickListener(new View.OnClickListener() {
			// 	@Override
			// 	public void onClick(View view) {
			//
			// 		// TODO get category and show movies based on that category
			// 		// TextView categoryText = view.findViewById(R.id.categoryText);
			//
			// 		// TODO display fragment that only shows those movies
			// 		((MainActivity) view.getContext())
			// 			.getSupportFragmentManager()
			// 			.beginTransaction()
			// 			.addToBackStack(null)
			// 			.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
			// 			.replace(R.id.fragmentContainer, new MoviesFragment())
			// 			.commit();
			// 	}
			// });
		}
	}
	
	private final Category[] categories;
	Fragment fragment;
	
	public CategoryAdapter(Category[] categories) {
		this.categories = categories;
	}
	
	@NonNull
	@Override
	public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		CardView cv = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.card_category, parent, false);
		return new ViewHolder(cv);
	}
	
	@Override
	public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
		CardView cardView = viewHolder.cardView;
		LinearLayout bg = cardView.findViewById(R.id.categoryBackground);
		TextView txt = cardView.findViewById(R.id.categoryText);
		
		String name = categories[position].name;
		txt.setText(name);
		
		int bgResource = 0;
		
		
		if (name.equalsIgnoreCase("classics"))
			bgResource = R.drawable.gradient_yellow;
		
		else if (name.equalsIgnoreCase("comedy"))
			bgResource = R.drawable.gradient_purple;
		
		else if (name.equalsIgnoreCase("action"))
			bgResource = R.drawable.gradient_blue;
		
		else if (name.equalsIgnoreCase("christmas"))
			bgResource = R.drawable.gradient_green;
		
		bg.setBackgroundResource(bgResource);
	}
	
	
	@Override
	public int getItemCount() {
		return categories.length;
	}
	
	
}
