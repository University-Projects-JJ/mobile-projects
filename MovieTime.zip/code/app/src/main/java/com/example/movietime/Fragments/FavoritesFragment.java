package com.example.movietime.Fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movietime.Adapters.CaptionedImageAdapter;
import com.example.movietime.Models.CaptionedImage;
import com.example.movietime.Models.Movie;
import com.example.movietime.R;
import com.thekhaeng.recyclerviewmargin.LayoutMarginDecoration;
import com.thekhaeng.recyclerviewmargin.OnClickLayoutMarginItemListener;

public class FavoritesFragment extends Fragment {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
													 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view = inflater.inflate(R.layout.fragment_favorites, container, false);
		// setHasOptionsMenu(true);
		setUpScrollableAdapters(view);
		return view;
	}
	
	private void setUpScrollableAdapters(View view) {
		
		RecyclerView rvFavorites = (RecyclerView) view.findViewById(R.id.rvFavorites);
		CaptionedImage[] captionedImages = CaptionedImage.captionedImageArrayFromMovie(Movie.MOVIES);
		rvFavorites.setAdapter(
			new CaptionedImageAdapter(captionedImages, R.layout.card_movie_simple_poster, (CaptionedImageAdapter.onCaptionedImageClickListener) getActivity(), null)
		);
		rvFavorites.setLayoutManager(
			new GridLayoutManager(getActivity(), 3, GridLayoutManager.VERTICAL, false)
		);
		
		LayoutMarginDecoration layoutMargin = new LayoutMarginDecoration( 3,32 );
		layoutMargin.setOnClickLayoutMarginItemListener(new OnClickLayoutMarginItemListener() {
			@Override
			public void onClick(Context context, View view, int position, int spanIndex, RecyclerView.State state) {
				// Toast.makeText( context, "item: " + position + "\ncolumn: " + spanIndex, Toast.LENGTH_SHORT ).show();
			}
		});
				rvFavorites.addItemDecoration( layoutMargin);
	}
	
	// @Override
	// public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
	// 	inflater.inflate(R.menu.menu_action_bar_search, menu);
	// 	super.onCreateOptionsMenu(menu, inflater);
	// }
}