package com.example.movietime.Models;

import com.example.movietime.R;

public class Category {
	public String name;
	
	public static final Category[] CATEGORIES = {
		new Category("Classics"),
		new Category("Action"),
		new Category("Comedy"),
		new Category("Christmas")
	};
	
	public Category(String name) {
		
		this.name = name;
	}
}
