package com.example.movietime.Adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movietime.Models.CaptionedImage;
import com.example.movietime.R;

public class CaptionedImageAdapter extends RecyclerView.Adapter<CaptionedImageAdapter.ViewHolder> {
	private onCaptionedImageClickListener monCaptionedImageClickListener;
	private String mType;
	
	public static final class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
		
		private CardView cardView;
		private onCaptionedImageClickListener onCaptionedImageClickListener;
		private String type;
		
		public ViewHolder(CardView cv, onCaptionedImageClickListener onCaptionedImageClickListener, @Nullable String type) {
			super(cv);
			cardView = cv;
			
			this.onCaptionedImageClickListener = onCaptionedImageClickListener;
			if (type==null)
				itemView.setOnClickListener(this);
		}
		
		@Override
		public void onClick(View view) {
			onCaptionedImageClickListener.onCaptionedImageClick(getAdapterPosition());
		}
	}
	
	private final CaptionedImage[] captionedImages;
	private final int resourceID;
	
	public CaptionedImageAdapter(CaptionedImage[] captionedImages, int resourceID,
															 CaptionedImageAdapter.onCaptionedImageClickListener onCaptionedImageClickListener, @Nullable String mType) {
		
		this.captionedImages = captionedImages;
		this.resourceID = resourceID;
		this.monCaptionedImageClickListener = onCaptionedImageClickListener;
		if(mType!=null)
		this.mType = mType;
	}
	
	@NonNull
	@Override
	public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		CardView cv = (CardView) LayoutInflater.from(parent.getContext()).inflate(resourceID, parent, false);
		return new ViewHolder(cv, monCaptionedImageClickListener, mType);
	}
	
	@Override
	public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
		CardView cardView = viewHolder.cardView;
		ImageView img = cardView.findViewById(R.id.img);
		
		CaptionedImage captionedImage = captionedImages[position];
		img.setImageResource(captionedImage.imgResourceID);
		
		if (resourceID == R.layout.card_simple_poster_caption) {
			TextView txtTitle = cardView.findViewById(R.id.txtCaption);
			txtTitle.setText(captionedImage.caption);
		}
		
	}
	
	@Override
	public int getItemCount() {
		return captionedImages.length;
	}
	
	public interface onCaptionedImageClickListener {
		void onCaptionedImageClick(int position);
	}
}
