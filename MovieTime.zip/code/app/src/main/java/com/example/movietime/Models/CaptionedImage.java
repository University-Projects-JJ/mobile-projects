package com.example.movietime.Models;

public class CaptionedImage {
	
	public int imgResourceID;
	public String caption;
	
	public CaptionedImage( String caption, int imgResourceID) {
		this.caption = caption;
		this.imgResourceID = imgResourceID;
	}
	
	public static CaptionedImage[] captionedImageArrayFromMovie(Movie[] movies){
		CaptionedImage[] captionedImages = new CaptionedImage[movies.length];
		
		for (int i=0; i< movies.length; i++)
			captionedImages[i] = new CaptionedImage(movies[i].title, movies[i].poster);
		
		return captionedImages;
	}
	
	public static CaptionedImage[] captionedImageArrayFromMovieCast(Movie movie){
		
		String[] castNames = movie.cast.split(",");
		int[] castImages = movie.castImages;
		
		CaptionedImage[] captionedImages = new CaptionedImage[castNames.length];
		
		for (int i=0; i< castNames.length; i++)
			captionedImages[i] = new CaptionedImage(castNames[i], castImages[i]);
		
		return captionedImages;
	}
}
