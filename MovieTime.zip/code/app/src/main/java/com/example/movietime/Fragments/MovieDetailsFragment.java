package com.example.movietime.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movietime.Adapters.CaptionedImageAdapter;
import com.example.movietime.Models.CaptionedImage;
import com.example.movietime.Models.Movie;
import com.example.movietime.R;

public class MovieDetailsFragment extends Fragment {
	private Movie movie;
	private CaptionedImageAdapter.onCaptionedImageClickListener onCaptionedImageClickListener;
	
	public MovieDetailsFragment(Movie movie, CaptionedImageAdapter.onCaptionedImageClickListener onCaptionedImageClickListener) {
		this.movie = movie;
		this.onCaptionedImageClickListener = onCaptionedImageClickListener;
	}
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
													 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view = inflater.inflate(R.layout.fragment_movie_details, container, false);
		
		setUpScrollableAdapters(view);
		fillData(view);
		return view;
	}
	
	private void fillData(View view) {
		ImageView imgMovie = view.findViewById(R.id.imgMovie);
		TextView txtTitle = view.findViewById(R.id.txtMovieTitle);
		TextView txtMovieYear = view.findViewById(R.id.txtMovieYear);
		TextView txtMoviePlot = view.findViewById(R.id.txtMoviePlot);
		TextView txtMovieDuration = view.findViewById(R.id.txtMovieDuration);
		TextView txtMovieRating = view.findViewById(R.id.txtMovieRating);
		
		imgMovie.setImageResource(movie.poster);
		txtTitle.setText(movie.title);
		txtMovieYear.setText(movie.year);
		txtMoviePlot.setText(movie.desc);
		txtMovieDuration.setText(movie.duration);
		txtMovieRating.setText(movie.rating + "");
		
	}
	
	private void setUpScrollableAdapters(View view) {
		CaptionedImage[] captionedImages = CaptionedImage.captionedImageArrayFromMovieCast(this.movie);
		RecyclerView rvCastImages = (RecyclerView) view.findViewById(R.id.rvCast);
		rvCastImages.setAdapter(
			new CaptionedImageAdapter(captionedImages, R.layout.card_simple_poster_caption, onCaptionedImageClickListener, "cast")
		);
		rvCastImages.setLayoutManager(
			new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false)
		);
	}
}