package com.example.movietime.Adapters;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.movietime.Models.Movie;
import com.example.movietime.R;

public class MovieDetailedAdapter extends RecyclerView.Adapter<MovieDetailedAdapter.ViewHolder> {
	
	public static final class ViewHolder extends RecyclerView.ViewHolder {
		CardView cardView;
		
		public ViewHolder(CardView cv) {
			super(cv);
			this.cardView = cv;
		}
	}
	
	private final Movie[] movies;
	
	public MovieDetailedAdapter(Movie[] movies) {
		this.movies = movies;
	}
	
	@NonNull
	@Override
	public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		CardView cv = (CardView) LayoutInflater.from(parent.getContext()).inflate(R.layout.card_movie_trending, parent, false);
		return new ViewHolder(cv);
	}
	
	@Override
	public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {
		CardView cardView = viewHolder.cardView;
		
		ImageView img = cardView.findViewById(R.id.imgMovie);
		TextView title = cardView.findViewById(R.id.txtMovieTitle);
		// TextView duration = cardView.findViewById(R.id.txtMovieDuration);
		TextView rating = cardView.findViewById(R.id.txtMovieRating);
		TextView year = cardView.findViewById(R.id.txtMovieYear);
		TextView rank = cardView.findViewById(R.id.txtRank);
		
		Movie movie = movies[position];
		img.setImageResource(movie.poster);
		title.setText(movie.title);
		year.setText(movie.year);
		// duration.setText(movie.duration);
		
		String ratingText = movie.rating+"";
		rating.setText(ratingText);
		
		String rankText = String.format("#%s", position+1);
		rank.setText(rankText);
		
		
	}
	
	@Override
	public int getItemCount() {
		return movies.length;
	}
	
	
}
