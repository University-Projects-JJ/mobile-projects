package com.example.countdown;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
	
	LinearLayout countdownContainer;
	View borderClock, borderCountdown;
	Handler updateScreen;
	SwitchCompat btnSwitch;
	ProgressBar progressBarGreen, progressBarYellow, progressBarOrange, progressBarRed;
	ProgressBar[] progressBars;
	Button btnStart, btnReset;
	TextView textTimeClock, textTimeCountdown;
	
	ImageButton btnMinUp, btnMinDown, btnSecUp, btnSecDown;
	
	private final String _TICKS = "TICKS";
	private final String _SET_TICKS = "SET_TICKS";
	private final String _RUNNING = "RUNNING";
	private final String _WAS_RUNNING = "WAS_RUNNING";
	
	private boolean isRunning = false;
	private boolean wasRunning = false;
	private boolean initLoad = true;
	
	private final int MAX_TICKS = 60 * 60 * 100;
	private final int DEFAULT_TICKS = 25 * 60 * 100;
	private int setTicks;
	private int ticks;
	private int secs;
	private int mins;
	
	
	private void initVariables(Bundle savedInstanceState) {
		
		this.countdownContainer = findViewById(R.id.countdownContainer);
		this.textTimeClock = findViewById(R.id.textTimeClock);
		this.textTimeCountdown = findViewById(R.id.textTime);
		
		this.borderClock = findViewById(R.id.borderClock);
		this.borderCountdown = findViewById(R.id.borderCountdown);
		this.btnSwitch = findViewById(R.id.btnToggle);
		
		this.btnReset = findViewById(R.id.btnReset);
		this.btnStart = findViewById(R.id.btnStart);
		
		this.btnMinUp = findViewById(R.id.minuteUp);
		this.btnMinDown = findViewById(R.id.minuteDown);
		this.btnSecUp = findViewById(R.id.secondUp);
		this.btnSecDown = findViewById(R.id.secondDown);
		
		
		this.progressBarGreen = findViewById(R.id.progressBar);
		this.progressBarYellow = findViewById(R.id.progressBarYellow);
		this.progressBarOrange = findViewById(R.id.progressBarOrange);
		this.progressBarRed = findViewById(R.id.progressBarRed);
		this.progressBars = new ProgressBar[]{progressBarGreen, progressBarOrange, progressBarYellow, progressBarRed};
		
		this.updateScreen = new Handler();
		
		if (savedInstanceState != null) {
			this.ticks = savedInstanceState.getInt(_TICKS);
			this.setTicks = savedInstanceState.getInt(_SET_TICKS);
			this.isRunning = savedInstanceState.getBoolean(_RUNNING);
			this.wasRunning = savedInstanceState.getBoolean(_WAS_RUNNING);
		}
		else {
			ticks = DEFAULT_TICKS;
			setTicks = ticks;
			
			secs = (DEFAULT_TICKS / 100) % 60;
			mins = DEFAULT_TICKS / 6000;
		}
	}
	
	@Override
	public void onSaveInstanceState(@NonNull Bundle outState) {
		super.onSaveInstanceState(outState);
		
		outState.putInt(_TICKS, ticks);
		outState.putInt(_SET_TICKS, setTicks);
		outState.putBoolean(_RUNNING, isRunning);
		outState.putBoolean(_WAS_RUNNING, wasRunning);
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initVariables(savedInstanceState);
		setUpClickListeners();
		
		updateScreen(true);
	}
	
	private void setUpClickListeners() {
		
		setUpControlListeners();
		
		
		btnStart.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				initLoad = false;
				setTicks = ticks;
				isRunning = !isRunning;
				int text = isRunning ? R.string.stop : R.string.start;
				btnStart.setText(text);
				hideControls(true);
				updateScreen(true);
			}
		});
		
		// reset
		btnReset.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				initLoad = true;
				ticks = DEFAULT_TICKS;
				setTicks = ticks;
				isRunning = false;
				setProgress();
				hideControls(false);
				updateScreen(true);
				btnStart.setText(R.string.start);
			}
		});
		
		
		// setting up time controls
		btnSwitch.setOnClickListener(
			new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (btnSwitch.isChecked()) {
						borderClock.setVisibility(View.INVISIBLE);
						borderCountdown.setVisibility(View.VISIBLE);
						
						countdownContainer.setVisibility(View.VISIBLE);
						textTimeClock.setVisibility(View.INVISIBLE);
						
					}
					else {
						borderCountdown.setVisibility(View.INVISIBLE);
						borderClock.setVisibility(View.VISIBLE);
						
						countdownContainer.setVisibility(View.INVISIBLE);
						textTimeClock.setVisibility(View.VISIBLE);
					}
					updateScreen(false);
				}
			});
		
	}
	
	private void setUpControlListeners() {
		btnMinUp.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				if (mins < 59 && ticks < MAX_TICKS) {
					ticks += 60 * 100;
					updateScreen(true);
				}
			}
		});
		
		btnMinDown.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View view) {
				
				if (mins > 0 && ticks > 0) {
					ticks -= 60 * 100;
					updateScreen(true);
				}
			}
		});
		
		btnSecUp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				if (secs < 59 && ticks < MAX_TICKS) {
					ticks += 100;
					updateScreen(true);
				}
			}
		});
		
		btnSecDown.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View view) {
				if (secs > 0 && ticks > 0) {
					ticks -= 100;
					updateScreen(true);
				}
			}
		});
	}
	
	private void hideControls(boolean hide) {
		int visibility = hide ? View.INVISIBLE : View.VISIBLE;
		btnMinUp.setVisibility(visibility);
		btnMinDown.setVisibility(visibility);
		btnSecUp.setVisibility(visibility);
		btnSecDown.setVisibility(visibility);
	}
	
	private void setProgress() {
		int progress = (int) ((ticks * 1.00 / setTicks) * 100);
		
		for (int i = 0; i < progressBars.length; i++)
			progressBars[i].setVisibility(View.INVISIBLE);
		
		if (progress >= 75) {
			
			progressBarGreen.setVisibility(View.VISIBLE);
			progressBarGreen.setProgress(progress);
		}
		
		else if (progress >= 50) {
			progressBarYellow.setVisibility(View.VISIBLE);
			progressBarYellow.setProgress(progress);
		}
		
		else if (progress >= 25) {
			progressBarOrange.setVisibility(View.VISIBLE);
			progressBarOrange.setProgress(progress);
		}
		
		else {
			progressBarRed.setVisibility(View.VISIBLE);
			progressBarRed.setProgress(progress);
		}
		
		
		//		COULD NOT MAKE THIS WORK
		//		int drawable = 0;
		//		if (progress >= 75)
		//			drawable = R.drawable.circular_progress_bar;
		//		else if (progress >= 50)
		//			drawable = R.drawable.circular_progress_bar_yellow;
		//		else if (progress >= 25)
		//			drawable = R.drawable.circular_progress_bar_yellow;
		//		else
		//			drawable = R.drawable.circular_progress_bar_yellow;
		//
		//		progressBarGreen.setProgressDrawable(ResourcesCompat.getDrawable(getResources(), drawable, null));
		
	}
	
	private void updateScreen(final boolean changed) {
		updateScreen.post(new Runnable() {
			@Override
			public void run() {
				//	countdown
				if (btnSwitch.isChecked()) {
					
					if (changed) {
						if (isRunning) {
							setProgress();
							ticks--;
						}
						secs = (ticks / 100) % 60;
						mins = (ticks / 6000);
						
						String displayTicks = initLoad ? "" : String.format(Locale.ENGLISH, ".%02d", ticks % 100);
						String displayString = String.format(Locale.ENGLISH, "%02d:%02d%s", mins, secs, displayTicks);
						textTimeCountdown.setText(displayString);
						
					}
					if (isRunning)
						updateScreen.postDelayed(this, 10);
				}
				// clock
				else {
					Date now = new Date();
					@SuppressWarnings("deprecation")
					String AM_PM = now.getHours() >= 12 ? "PM" : "AM"; // ignore deprecated.
					String result = new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH).format(now) + " " + AM_PM;
					textTimeClock.setText(result);
					updateScreen.postDelayed(this, 1000);
				}
			}
		});
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		isRunning = wasRunning;
	}
	
	
	@Override
	protected void onStop() {
		super.onStop();
		wasRunning = isRunning;
		isRunning = false;
	}
	
	
}