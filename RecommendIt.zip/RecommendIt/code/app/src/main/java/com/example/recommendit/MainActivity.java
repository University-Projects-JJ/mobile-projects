package com.example.recommendit;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
	
	RelativeLayout optionsContainer;
	ArrayList<RadioButton> radioOptions;
	ArrayList<TextView> textOptions;
	Spinner spinnerCategory;
	Button btnRecommend;
	String selectedOption;
	public final static String FINAL_OPTION_VALUE = "option_value";
	public final static String FINAL_CATEGORY_VALUE = "category_value";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initVariables();
		setUpSelectListener(this.spinnerCategory);
	}
	
	
	protected void initVariables() {
		
		//  init options container
		this.optionsContainer = findViewById(R.id.optionsContainer);
		
		// for loop keeps throwing error so doing it manually
		ArrayList<LinearLayout> optionsLayouts = new ArrayList<>();
		optionsLayouts.add((LinearLayout) findViewById(R.id.option1Container));
		optionsLayouts.add((LinearLayout) findViewById(R.id.option2Container));
		optionsLayouts.add((LinearLayout) findViewById(R.id.option3Container));
		optionsLayouts.add((LinearLayout) findViewById(R.id.option4Container));
		
		// get radioButton options from the above
		this.radioOptions = new ArrayList<>();
		this.textOptions = new ArrayList<>();
		for (LinearLayout optionLayout : optionsLayouts) {
			radioOptions.add((RadioButton) optionLayout.getChildAt(0));
			textOptions.add((TextView) optionLayout.getChildAt(1));
		}
		
		
		// get Spinner
		this.spinnerCategory = findViewById(R.id.chooseCategorySpinner);
		
		// get button
		this.btnRecommend = findViewById(R.id.buttonRecommend);
		
		this.selectedOption = "";
	}
	
	private void clearOptions(int id) {
		

			for (int i = 0; i < this.radioOptions.size(); i++) {
				RadioButton option = radioOptions.get(i);
				TextView text = textOptions.get(i);
				
				if (option.getId() == id) {
					selectedOption = text.getText().toString();
					option.setChecked(true);
					text.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
					text.setTextColor(getResources().getColor(R.color.white));
				} else {
					// resetting all
					if (id == 0) {
						this.selectedOption="";
					}
					option.setChecked(false);
					text.setBackgroundColor(getResources().getColor(R.color.transparent));
					text.setTextColor(getResources().getColor(R.color.black));
			}
		}
	}
	
	
	public void onOptionClick(View view) {
		clearOptions(view.getId());
	}
	
	public void onRecommendClick(View view) {
		if (!selectedOption.isEmpty()) {
			Intent intent = new Intent(this, RecommendationEngine.class);
			intent.putExtra(FINAL_CATEGORY_VALUE, this.spinnerCategory.getSelectedItem().toString());
			intent.putExtra(FINAL_OPTION_VALUE, selectedOption);
			startActivity(intent);
		} else {
			Toast.makeText(this, "please select an option", Toast.LENGTH_SHORT).show();
		}
	}
	
	private void setVisibleItems(String selectedCategory) {
			clearOptions(0);
		if (selectedCategory.equals("What would you like to do today?")) {
			optionsContainer.setVisibility(View.GONE);
		} else {
			optionsContainer.setVisibility(View.VISIBLE);
			if (selectedCategory.equals("Eat"))
				setFoodItems();
			if (selectedCategory.equals("Travel"))
				setTravelItems();
			if (selectedCategory.equals("Watch a Movie"))
				setMovieItems();
			if (selectedCategory.equals("Listen to Music"))
				setMusicItems();
		}
	}
	
	private void setFoodItems() {
		// option 1
		radioOptions.get(0).setButtonDrawable(null);
		radioOptions.get(0).setButtonDrawable(R.drawable.ic_food_healthy);
		textOptions.get(0).setText(R.string.food_healthy);
		// option 2
		radioOptions.get(1).setButtonDrawable(null);
		radioOptions.get(1).setButtonDrawable(R.drawable.ic_food_dessert);
		textOptions.get(1).setText(R.string.food_dessert);
		// option 3
		radioOptions.get(2).setButtonDrawable(null);
		radioOptions.get(2).setButtonDrawable(R.drawable.ic_food_fast);
		textOptions.get(2).setText(R.string.food_fast);
		// option 4
		radioOptions.get(3).setButtonDrawable(null);
		radioOptions.get(3).setButtonDrawable(R.drawable.ic_food_spicy);
		textOptions.get(3).setText(R.string.food_spicy);
	}
	
	private void setTravelItems() {
		// option 1
		radioOptions.get(0).setButtonDrawable(null);
		radioOptions.get(0).setButtonDrawable(R.drawable.ic_travel_tropical);
		textOptions.get(0).setText(R.string.travel_tropical);
		// option 2
		radioOptions.get(1).setButtonDrawable(null);
		radioOptions.get(1).setButtonDrawable(R.drawable.ic_travel_desert);
		textOptions.get(1).setText(R.string.travel_desert);
		// option 3
		radioOptions.get(2).setButtonDrawable(null);
		radioOptions.get(2).setButtonDrawable(R.drawable.ic_travel_forest);
		textOptions.get(2).setText(R.string.travel_forest);
		// option 4
		radioOptions.get(3).setButtonDrawable(null);
		radioOptions.get(3).setButtonDrawable(R.drawable.ic_travel_mountain);
		textOptions.get(3).setText(R.string.travel_mountain);
	}
	
	private void setMusicItems() {
		// option 1
		radioOptions.get(0).setButtonDrawable(null);
		radioOptions.get(0).setButtonDrawable(R.drawable.ic_music_pop);
		textOptions.get(0).setText(R.string.music_pop);
		// option 2
		radioOptions.get(1).setButtonDrawable(null);
		radioOptions.get(1).setButtonDrawable(R.drawable.ic_music_80s);
		textOptions.get(1).setText(R.string.music_80s);
		// option 3
		radioOptions.get(2).setButtonDrawable(null);
		radioOptions.get(2).setButtonDrawable(R.drawable.ic_music_love);
		textOptions.get(2).setText(R.string.music_love);
		// option 4
		radioOptions.get(3).setButtonDrawable(null);
		radioOptions.get(3).setButtonDrawable(R.drawable.ic_music_sad);
		textOptions.get(3).setText(R.string.music_sad);
	}
	
	private void setMovieItems() {
		// option 1
		radioOptions.get(0).setButtonDrawable(null);
		radioOptions.get(0).setButtonDrawable(R.drawable.ic_movie_action);
		textOptions.get(0).setText(R.string.movie_action);
		// option 2
		radioOptions.get(1).setButtonDrawable(null);
		radioOptions.get(1).setButtonDrawable(R.drawable.ic_movie_scifi);
		textOptions.get(1).setText(R.string.movie_scifi);
		// option 3
		radioOptions.get(2).setButtonDrawable(null);
		radioOptions.get(2).setButtonDrawable(R.drawable.ic_movie_comedy);
		textOptions.get(2).setText(R.string.movie_comedy);
		// option 4
		radioOptions.get(3).setButtonDrawable(null);
		radioOptions.get(3).setButtonDrawable(R.drawable.ic_movie_rom);
		textOptions.get(3).setText(R.string.movie_rom);
	}
	
	private void setUpSelectListener(final Spinner spinner) {
		spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
				String selectedCategory = spinner.getSelectedItem().toString();
				setVisibleItems(selectedCategory);
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> parentView) {
				// your code here
			}
			
		});
	}
	
}