package com.example.recommendit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class RecommendationEngine extends AppCompatActivity {
	String category, option, verb, recommendation;
	Drawable img;
	ImageView imgRecommendation;
	TextView textViewRecommendation, resultTextRecommendation;
	Button btnBack;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_recommendation_engine);
		initVariables();
		getRecommendation();
		setResults();
		
	}
	
	private void initVariables() {
		// get Intent and received variables
		Intent intent = getIntent();
		this.category = intent.getStringExtra(MainActivity.FINAL_CATEGORY_VALUE);
		this.option = intent.getStringExtra(MainActivity.FINAL_OPTION_VALUE);
		
		this.textViewRecommendation = (TextView) findViewById(R.id.recommendationText);
		this.imgRecommendation = (ImageView)findViewById(R.id.recommendationImg);
		this.btnBack = (Button) findViewById(R.id.buttonBack);
		
		this.resultTextRecommendation = (TextView) findViewById(R.id.recommendation);
	}
	
	@SuppressLint("UseCompatLoadingForDrawables")
	private void getRecommendation() {
		if (category.equals("Eat")) {
			this.verb = "eating";
			
			if (option.equals("Healthy")) {
				recommendation = "Ham & Cheese";
				img = getResources().getDrawable(R.drawable.ic_result_food_healthy);
			}
			if (option.equals("Dessert")) {
				recommendation = "Waffles";
				img = getResources().getDrawable(R.drawable.ic_result_food_dessert);
			}
			if (option.equals("Spicy")) {
				recommendation = "Tacos";
				img = getResources().getDrawable(R.drawable.ic_result_food_spicy);
			}
			if (option.equals("Fast Food")) {
				recommendation = "Pizza";
				img = getResources().getDrawable(R.drawable.ic_result_food_fast);
			}
		} else if (this.category.equals("Travel")) {
			this.verb = "travelling to";
			
			if (option.equals("Forests")) {
				recommendation = "The Amazon Forest";
				img = getResources().getDrawable(R.drawable.ic_result_travel_forest);
			}
			if (option.equals("Mountains")) {
				recommendation = "The French Alps";
				img = getResources().getDrawable(R.drawable.ic_result_travel_mountain);
			}
			if (option.equals("Deserts")) {
				recommendation = "Egypt";
				img = getResources().getDrawable(R.drawable.ic_result_travel_desert);
			}
			if (option.equals("Tropical")) {
				recommendation = "Bora Bora";
				img = getResources().getDrawable(R.drawable.ic_result_travel_tropical);
			}
		} else if (this.category.equals("Watch a Movie")) {
			this.verb = "watching";
			
			if (option.equals("Action")) {
				recommendation = "Rambo";
				img = getResources().getDrawable(R.drawable.ic_result_movie_action);
			}
			if (option.equals("Comedy")) {
				recommendation = "Game Night";
				img = getResources().getDrawable(R.drawable.ic_result_movie_comedy);
			}
			if (option.equals("Romantic")) {
				recommendation = "Valetine's Day";
				img = getResources().getDrawable(R.drawable.ic_result_movie_rom);
			}
			if (option.equals("Sci Fi")) {
				recommendation = "Star Wars IV: A New Hope";
				img = getResources().getDrawable(R.drawable.ic_result_movie_scifi);
			}
		} else if (this.category.equals("Listen to Music")) {
			this.verb = "listening to";
			
			if (option.equals("Pop")) {
				recommendation = "KPOP";
				img = getResources().getDrawable(R.drawable.ic_result_music_pop);
			}
			if (option.equals("80s Disco")) {
				recommendation = "Prince";
				img = getResources().getDrawable(R.drawable.ic_result_music_80s);
			}
			if (option.equals("Sad")) {
				recommendation = "Jess Glyne";
				img = getResources().getDrawable(R.drawable.ic_result_music_sad);
			}
			if (option.equals("Love")) {
				recommendation = "Paul Anka";
				img = getResources().getDrawable(R.drawable.ic_result_music_love);
			}
		}
	}
	
	private void setResults() {
		String result = String.format("%s %s", getResources().getString(R.string.recommendation_text), verb);
		textViewRecommendation.setText(result);
		imgRecommendation.setImageDrawable(img);
		resultTextRecommendation.setText(String.format("%s!",recommendation));
	}
	
	public void onBackClick(View view){
		Intent intent = new Intent(this,MainActivity.class);
		startActivity(intent);
	}
}