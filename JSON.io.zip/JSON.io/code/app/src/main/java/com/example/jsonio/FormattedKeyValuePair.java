package com.example.jsonio;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.StyleableRes;

public class FormattedKeyValuePair extends LinearLayout {
	
	@StyleableRes
	int index0 = 0;
	@StyleableRes
	int index1 = 1;
	
	TextView keyText, valueText;
	
	public FormattedKeyValuePair(Context context, AttributeSet attrs) {
		super(context, attrs);
		init(context, attrs);
	}
	
	private void init(Context context, AttributeSet attrs) {
		inflate(context, R.layout.formatted_key_value_pair, this);
		
		int[] sets = {R.attr.key, R.attr.value};
		TypedArray typedArray = context.obtainStyledAttributes(attrs, sets);
		String key = typedArray.getText(index0) == null ? "" : typedArray.getText(index0).toString();
		String value = typedArray.getText(index1) == null ? "" : typedArray.getText(index1).toString();
		typedArray.recycle();
		
		initVariables();
		
		setKey(key);
		setValue(value);
	}
	

	
	
	private void initVariables() {
		keyText = (TextView) findViewById(R.id.formattedKey);
		valueText = (TextView) findViewById(R.id.formattedValue);
	}
	
	public String getKey() {
		return this.keyText.getText().toString();
	}
	
	public void setKey(String key) {
		key = "\"" + key + "\"";
		this.keyText.setText(key);
	}
	
	public String getValue() {
		return this.valueText.getText().toString();
	}
	
	public void setValue(String value) {
		value = "\"" + value + "\"";
		this.valueText.setText(value);
	}
}