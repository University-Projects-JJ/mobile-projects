package com.example.jsonio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
	
	// app variables
	final Handler formatterHandler = new Handler(); // used to format the added pairs
	
	// layout variables
	LinearLayout formattedJSONLayout; // contains the formatted pair LinearLayouts
	Button btnClear, btnSend;
	ImageButton btnAdd;
	EditText keyEdit, valueEdit;
	
	// custom variables
	ArrayList<String> addedKeys; // keep track of keys to avoid duplicates
	LinkedHashMap<String, String> keyValueStrings = new LinkedHashMap<>(); // used to return the formatted JSON to avoid an extra loop
	boolean isEmpty = true; // used to check if formattedLayout is empty => otherwise update issues are arising.
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		intiVariables();
	}
	
	private void intiVariables() {
		this.formattedJSONLayout = findViewById(R.id.formattedJSON);
		
		this.btnAdd = (ImageButton) findViewById(R.id.btnAdd);
		this.btnClear = (Button) findViewById(R.id.btnClear);
		this.btnSend = (Button) findViewById(R.id.btnSend);
		
		this.keyEdit = (EditText) findViewById(R.id.key);
		this.valueEdit = (EditText) findViewById(R.id.value);
		
		this.addedKeys = new ArrayList<>();
	}
	
	// calls the addPair method if the add button is clicked
	public void onClickAdd(View view) {
		addPair();
	}
	
	// calls the clear methods to clear all user input
	public void onClickClear(View view) {
		clearJSON();
		clearFields();
	}
	
	// calls the sendJSONData method to prepare and send the data
	public void onClickSend(View view) {
		if (!isEmpty)
			sendJSONData();
		else
			Toast.makeText(this, "JSON Object cannot be empty!", Toast.LENGTH_LONG).show();
	}
	
	private void sendJSONData() {
		final JSONObject json = new JSONObject(); // create JSON Object
		final Handler waitForUpdate = new Handler();
		
		formatJSON(true);
		
		// using runnable to check if JSON has been formatted for export => to avoid empty object
		waitForUpdate.post(new Runnable() {
			@Override
			public void run() {
				if (keyValueStrings.isEmpty())
					waitForUpdate.postDelayed(this, 200);
				
				try {
					
					for (Map.Entry<String, String> pair : keyValueStrings.entrySet())
						json.put(pair.getKey(), pair.getValue()); // Put key-value pairs in the JSON Object
					
				}
				catch (NullPointerException e) {
					Toast.makeText(MainActivity.this, "Preparing For Export", Toast.LENGTH_LONG).show();
				}
				catch (JSONException e) {
					Toast.makeText(MainActivity.this, "There was an error parsing the JSON data.", Toast.LENGTH_LONG).show();
				}
				
				// Create email intent and call app chooser
				Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
				emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your JSON object");
				emailIntent.putExtra(Intent.EXTRA_TEXT, json.toString().replaceAll(",", ",\n"));
				
				startActivity(Intent.createChooser(emailIntent, "Send By Email"));
			}
		});
	}
	
	// get keys from user input, clean and add them to the JSON viewer
	private void addPair() {
		
		String key = keyEdit.getText().toString().replaceAll(" ", ""); // remove whitespace
		String value = valueEdit.getText().toString().trim();
		
		if (key.equals("")) {
			Toast.makeText(this, "Key cannot be empty!", Toast.LENGTH_SHORT).show();
		}
		else if (addedKeys.contains(key)) {
			Toast.makeText(this, key+" has already been added!", Toast.LENGTH_SHORT).show();
		}
		else if (!key.matches("[_a-zA-Z0-9]+")) {
			Toast.makeText(this, "Please make sure the key is alphanumeric!", Toast.LENGTH_SHORT).show();
		}
		else {
			LinearLayout newPair = (LinearLayout) this.getLayoutInflater().inflate(R.layout.formatted_key_value_pair, null);
			TextView keyText = (TextView) newPair.findViewById(R.id.formattedKey);
			TextView valueText = (TextView) newPair.findViewById(R.id.formattedValue);
			
			addedKeys.add(key);
			
			// if integer, make orange
			int valueInt = 0;
			double valueDouble = 0.0;
			
			try {
				valueInt = Integer.parseInt(value);
				valueText.setTextColor(getResources().getColor(R.color.orange));
			}
			catch (NumberFormatException e) {
				try {
					valueDouble = Double.parseDouble(value);
					valueText.setTextColor(getResources().getColor(R.color.orange));
					value = valueInt == valueDouble ? valueInt + "" : valueDouble + "";
				}
				catch (Exception err) {
					// if boolean make purple
					if (value.equals("true") || value.equals("false"))
						valueText.setTextColor(getResources().getColor(R.color.purple));
					else
						value = "\"" + value.trim() + "\"";
					
				}
			}
			
			key = "\"" + key.trim() + "\"";
			keyText.setText(key);
			valueText.setText(value);
			
			formattedJSONLayout.addView(newPair, formattedJSONLayout.getChildCount() - 1);
			isEmpty = false;
			
			formatJSON(false);
			clearFields();
		}
	}
	
	
	// format the JSON key value pairs for viewing or export
	private void formatJSON(final boolean export) {
		
		// using handler to avoid null values
		formatterHandler.post(new Runnable() {
			@Override
			public void run() {
				if (!isEmpty) {
					for (int i = 1; i < formattedJSONLayout.getChildCount() - 1; i++) {
						View child = formattedJSONLayout.getChildAt(i);
						if (child instanceof LinearLayout) {
							
							TextView keyText = child.findViewById(R.id.formattedKey);
							TextView valueText = child.findViewById(R.id.formattedValue);
							
							if (keyText != null && valueText != null) {
								String key = keyText.getText().toString();
								String value = valueText.getText().toString();
								
								if (export) {
									key = key.replaceAll("\"", "");
									value = value.replaceAll("\"", "").replace(",", "");
									
									keyValueStrings.put(key, value);
								}
								else {
									if (i != formattedJSONLayout.getChildCount() - 2) {
										value = value.replace(",", "").concat("<font color='#000000'>,</font>");
										valueText.setText(Html.fromHtml(value));
									}
								}
							}
						}
					}
				}
			}
		});
	}
	
	private void clearFields() {
		this.keyEdit.setText("");
		this.valueEdit.setText("");
	}
	
	public void clearJSON() {
		for (int i = 1; i < formattedJSONLayout.getChildCount() - 1; i++) {
			View child = formattedJSONLayout.getChildAt(i);
			if (child instanceof LinearLayout)
				((LinearLayout) child).removeAllViews();
		}
		addedKeys.clear();
		keyValueStrings.clear();
		isEmpty = true;
	}
}