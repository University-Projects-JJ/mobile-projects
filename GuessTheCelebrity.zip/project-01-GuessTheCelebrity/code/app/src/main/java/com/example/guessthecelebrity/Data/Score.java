package com.example.guessthecelebrity.Data;

public class Score {
	
	public static final int LIMIT = 5;
	
	private String name;
	private String date;
	private int score;
	
	public Score(String name, String date, int score) {
		this.name = name;
		this.date = date;
		this.score = score;
	}
	
	public String getName() {
		return name;
	}
	
	public String toString() {
		return this.name + " " + this.score + " " + this.date;
	}
}
