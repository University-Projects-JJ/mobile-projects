package com.example.guessthecelebrity.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.guessthecelebrity.Data.CelebrityGameSQLOH;
import com.example.guessthecelebrity.Data.Question;
import com.example.guessthecelebrity.Data.QuestionPair;
import com.example.guessthecelebrity.Data.Score;
import com.example.guessthecelebrity.Fragments.QuestionFragment;
import com.example.guessthecelebrity.R;

import java.util.ArrayList;
import java.util.Locale;

public class GameActivity extends AppCompatActivity {
	
	// quiz
	private ArrayList<QuestionPair> questionnaire;
	private QuestionPair currentQuestion;
	private String currentQuestionName;
	private String currentQuestionProvidedName;
	private int currentQuestionNumber = 0;
	
	// timer
	private CountDownTimer timer;
	private final long TIME_START = 6000;
	private long timeLeft;
	
	
	// player
	private int score = 0;
	private String playerName;
	
	// DOM
	Button btnTrue, btnFalse;
	TextView txtTimer;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_game);
		
		initVariables();
		setUpGame();
		setUpListeners();
		startGame();
		
	}
	
	private void initVariables() {
		this.btnTrue = findViewById(R.id.btnTrue);
		this.btnFalse = findViewById(R.id.btnFalse);
		this.txtTimer = findViewById(R.id.txtTimer);
		
		Intent mainIntent = getIntent();
		this.playerName = mainIntent.getStringExtra("NAME");
	}
	
	// checks if question is correct and loads next question
	private void setUpListeners() {
		
		View.OnClickListener btnClick = new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
				Boolean answer = view.getId() == R.id.btnTrue;
				boolean isCorrect = currentQuestionName.equalsIgnoreCase(currentQuestionProvidedName) == answer;
				
				if (isCorrect)
					score++;
				
				loadNextQuestion();
				
				String toastReply = isCorrect ?
															getResources().getString(R.string.guess_correct) :
															getResources().getString(R.string.guess_wrong);
				
				Toast toast = Toast.makeText(GameActivity.this, toastReply, Toast.LENGTH_SHORT);
				toast.show();
				
				// remove toast sooner
				synchronized (this) {
					try {
						wait(300);
						toast.cancel();
					}
					catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		
		this.btnTrue.setOnClickListener(btnClick);
		this.btnFalse.setOnClickListener(btnClick);
	}
	
	private void setUpGame() {
		ArrayList<Question> questions = fetchQuestionsFromDatabase();
		
		if (questions != null)
			this.questionnaire = generateQuestionnaire(questions);
	}
	
	private void startGame() {
		loadNextQuestion();
	}
	
	private void startCountdown() {
		
		timeLeft = TIME_START;
		if (timer != null)
			timer.cancel();
		
		timer = new CountDownTimer(timeLeft, 1000) {
			@Override
			public void onTick(long leftAfterTick) {
				timeLeft = leftAfterTick;
				updateTimer();
			}
			
			@Override
			public void onFinish() {
				timeLeft = 0;
				loadNextQuestion();
			}
		}.start();
	}
	
	private void updateTimer() {
		long secs = (timeLeft / 1000) % 60;
		
		String timeFormatted = String.format(Locale.getDefault(), "00:%02d", secs);
		this.txtTimer.setText(timeFormatted);
	}
	
	private void loadNextQuestion() {
		
		if (currentQuestionNumber == questionnaire.size())
			endGame();
		else {
			currentQuestion = questionnaire.get(currentQuestionNumber++);
			currentQuestionName = currentQuestion.question.getName();
			currentQuestionProvidedName = currentQuestion.answer;
			
			FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
			QuestionFragment questionFragment = new QuestionFragment(currentQuestionProvidedName, currentQuestion.question.getImgResourceID());
			
			ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
			ft.replace(R.id.questionFragment, questionFragment);
			ft.addToBackStack(null);
			ft.commit();
			startCountdown();
		}
	}
	
	private void endGame() {
		if (timer != null)
			timer.cancel();
		
		Intent resultsIntent = new Intent(this, ResultsActivity.class);
		resultsIntent.putExtra("SCORE", score);
		resultsIntent.putExtra("NAME", playerName);
		startActivity(resultsIntent);
	}
	
	
	private ArrayList<QuestionPair> generateQuestionnaire(ArrayList<Question> questions) {
		
		ArrayList<Integer> possible = new ArrayList<>();
		ArrayList<Integer> selected = new ArrayList<>();
		ArrayList<QuestionPair> selectedQuestions = new ArrayList<>();
		
		// get possible indices we can pick based on the number of questions in the  database;
		for (int i = 0; i < questions.size(); i++)
			possible.add(i);
		
		// until 5 questions are picked
		while (selected.size() < Score.LIMIT) {
			
			// generate a random index and pick a question index
			// remove that index to avoid duplicate questions
			int random = (int) Math.floor(Math.random() * possible.size());
			selected.add(possible.remove(random));
		}
		
		// then for each selected question
		for (int i = 0; i < selected.size(); i++) {
			
			// get other questions by removing selected question
			ArrayList<Question> remainingQuestions = new ArrayList<>(questions);
			remainingQuestions.remove(selected.get(i));
			
			// select question
			Question selectedQuestion = questions.get(selected.get(i));
			
			
			// for each selected Question generate random probability p
			// if p>= 0.5 => use the correct name for the question
			// if p<0.5 => randomly select from one of the other questions
			// this is correct because Math.random() generates a random double in [0.0, 1.0)
			double probability = (double) ((int) (Math.random() * 10)) / 10.0; // *10/10 to get only  2 decimal places (optional)
			
			if (probability >= 0.5)
				selectedQuestions.add(new QuestionPair(selectedQuestion, selectedQuestion.getName()));
			else {
				int randomIndex = (int) Math.floor(Math.random() * remainingQuestions.size());
				String randomNameFromRemaining = remainingQuestions.get(randomIndex).getName();
				selectedQuestions.add(new QuestionPair(selectedQuestion, randomNameFromRemaining));
			}
			
			
		}
		return selectedQuestions;
	}
	
	
	private ArrayList<Question> fetchQuestionsFromDatabase() {
		try {
			ArrayList<Question> questions = new ArrayList<>();
			
			SQLiteOpenHelper celebrityGameSQLOH = new CelebrityGameSQLOH(this);
			SQLiteDatabase db = celebrityGameSQLOH.getReadableDatabase();
			
			Cursor cursor = db.query(
				CelebrityGameSQLOH.DB_TABLE_QUESTION,
				new String[]{
					CelebrityGameSQLOH.DB_QUESTION_NAME,
					CelebrityGameSQLOH.DB_QUESTION_IMG
				},
				null, null, null, null, null
			);
			
			while (cursor.moveToNext()) {
				Question qs = new Question(
					cursor.getString(0),
					cursor.getInt(1));
				
				questions.add(qs);
			}
			
			cursor.close();
			db.close();
			
			return questions;
			
		}
		catch (Exception e) {
			CelebrityGameSQLOH.showError(this);
		}
		return null;
	}
	
}