package com.example.guessthecelebrity.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guessthecelebrity.Data.CelebrityGameSQLOH;
import com.example.guessthecelebrity.R;

public class MainActivity extends AppCompatActivity {
	
	TextView highScore;
	EditText inpName;
	Button btnNewGame, btnScores;
	int high=0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		getScoresFromDatabase();
		initVariables();
		SetUpListeners();
	}
	
	private void initVariables() {
		highScore = findViewById(R.id.highScore);
		inpName = findViewById(R.id.inpName);
		btnNewGame = findViewById(R.id.btnNewGame);
		btnScores = findViewById(R.id.btnScores);
		
		highScore.setText(high+"");
	}
	
	private void getScoresFromDatabase(){
		
		
		try {
			SQLiteOpenHelper celebrityGameSQLOH = new CelebrityGameSQLOH(this);
			SQLiteDatabase db = celebrityGameSQLOH.getReadableDatabase();
			Cursor cursor = db.query(
				CelebrityGameSQLOH.DB_TABLE_SCORE,
				
				new String[]{
					"_id",
					CelebrityGameSQLOH.DB_SCORE_NAME,
					CelebrityGameSQLOH.DB_SCORE_SCORE,
					CelebrityGameSQLOH.DB_SCORE_DATE,
				},
				null,null,null,null,null
			);
			
			while (cursor.moveToNext()){
				int score = cursor.getInt(2);
				high = Math.max(score, high);
			}
			cursor.close();
			db.close();
		}
		catch (Exception e) {
			CelebrityGameSQLOH.showError(this);
		}
	}
	
	
	private void SetUpListeners() {
		btnNewGame.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				
				String name = !inpName.getText().toString().isEmpty() ? inpName.getText().toString() : "player";
				
				Intent intent = new Intent(MainActivity.this, GameActivity.class);
				intent.putExtra("NAME", name);
				startActivity(intent);
			}
		});
		
		btnScores.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent intent = new Intent(MainActivity.this, ScoresActivity.class);
				startActivity(intent);
			}
		});
	}
}