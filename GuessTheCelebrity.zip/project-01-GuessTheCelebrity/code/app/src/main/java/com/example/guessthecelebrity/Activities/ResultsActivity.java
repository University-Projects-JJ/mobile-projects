package com.example.guessthecelebrity.Activities;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guessthecelebrity.Data.CelebrityGameSQLOH;
import com.example.guessthecelebrity.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ResultsActivity extends AppCompatActivity {
	TextView txtScore;
	Button btnMainMenu, btnScores;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_results);
		
		initVariables();
		setUpListeners();
		
		displayAndSaveScore();
	}
	
	private void displayAndSaveScore() {
		Intent gameActivityIntent = getIntent();
		int score = gameActivityIntent.getIntExtra("SCORE", 0);
		
		
		String playerName = gameActivityIntent.getStringExtra("NAME");
		
		this.txtScore.setText(score + "");
		
		try {
			CelebrityGameSQLOH celebrityGameSQLOH = new CelebrityGameSQLOH(this);
			SQLiteDatabase db = celebrityGameSQLOH.getWritableDatabase();
			
			DateFormat df = new SimpleDateFormat("MMMM dd | hh:mmaa", Locale.getDefault());
			String date = df.format(new Date());
			
			celebrityGameSQLOH.insertScore(db, playerName, score, date);
		}
		catch (Exception e) {
			CelebrityGameSQLOH.showError(this);
		}
		
		
	}
	
	private void initVariables() {
		this.txtScore = findViewById(R.id.Score);
		this.btnMainMenu = findViewById(R.id.btnMainMenu);
		this.btnScores = findViewById(R.id.btnScores);
	}
	
	private void setUpListeners() {
		View.OnClickListener btnListener = new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent intent = new Intent();
				if (view.getId() == R.id.btnMainMenu) {
					intent.setClass(ResultsActivity.this, MainActivity.class);
					startActivity(intent);
				}
				else if (view.getId() == R.id.btnScores) {
					intent.setClass(ResultsActivity.this, ScoresActivity.class);
					startActivity(intent);
				}
			}
		};
		btnMainMenu.setOnClickListener(btnListener);
		btnScores.setOnClickListener(btnListener);
		
	}
}