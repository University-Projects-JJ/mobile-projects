package com.example.guessthecelebrity.Data;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.guessthecelebrity.R;

public class CelebrityGameSQLOH extends SQLiteOpenHelper {
	
	// DB
	private static final String DB_NAME = "GUESS_THE_CELEBRITY";
	private static final int DB_VERSION = 1;
	
	// QUESTION TABLE
	public static final String DB_TABLE_QUESTION = "QUESTION";
	// COLS
	public static final String DB_QUESTION_NAME = "CELEBRITY_NAME";
	public static final String DB_QUESTION_IMG = "CELEBRITY_IMG";
	
	// SCORE TABLE
	public static final String DB_TABLE_SCORE = "SCORE";
	// COLS
	public static final String DB_SCORE_NAME = "PLAYER_NAME";
	public static final String DB_SCORE_SCORE = "SCORE";
	public static final String DB_SCORE_DATE = "DATE";
	
	
	public CelebrityGameSQLOH(@Nullable Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE QUESTION (" +
								 "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
								 DB_QUESTION_NAME + " " + "TEXT," +
								 DB_QUESTION_IMG + " "+"INTEGER" +
								 ")");
		
		db.execSQL("CREATE TABLE SCORE (" +
								 "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
								 DB_SCORE_NAME +" " +"TEXT," +
								 DB_SCORE_SCORE +" "+"INTEGER," +
								 DB_SCORE_DATE +" "+ "TEXT" +
								 ")");
		
		addQuestionsToDatabase(db);
		
	}
	
	private void addQuestionsToDatabase(SQLiteDatabase db) {
		insertQuestion(db, "Alexandra Daddario", R.drawable.alexandra_daddario);
		insertQuestion(db, "Brad Pitt", R.drawable.brad_pitt);
		insertQuestion(db, "Emilia Clarke", R.drawable.emilia_clarke);
		insertQuestion(db, "Leonardo Dicaprio", R.drawable.leonardo_dicaprio);
		insertQuestion(db, "Matthew Mcconaughey", R.drawable.matthew_mcconaughey);
		insertQuestion(db, "Sacha Baron Cohen", R.drawable.sacha_baron_cohen);
		insertQuestion(db, "Sarah Paulson", R.drawable.sarah_paulson);
		insertQuestion(db, "Scarlett Johanson", R.drawable.scarlett_johansson);
		insertQuestion(db, "Tom Cruise", R.drawable.tom_cruise);
		insertQuestion(db, "Tom Hanks", R.drawable.tom_hanks);
	}
	
	private void insertQuestion(SQLiteDatabase db, String name, int imgID) {
		ContentValues contentValues = new ContentValues();
		contentValues.put(DB_QUESTION_NAME, name);
		contentValues.put(DB_QUESTION_IMG, imgID);
		
		db.insert(DB_TABLE_QUESTION, null, contentValues);
	}
	
	public void insertScore(SQLiteDatabase db, String name, int score, String date) {
		ContentValues contentValues = new ContentValues();
		contentValues.put(DB_SCORE_NAME, name);
		contentValues.put(DB_SCORE_SCORE, score);
		contentValues.put(DB_SCORE_DATE, date);
		
		db.insert(DB_TABLE_SCORE, null, contentValues);
	}
	
	
	public static void showError(Context context){
		Toast.makeText(context, R.string.database_error, Toast.LENGTH_SHORT).show();
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
	}
}
