package com.example.guessthecelebrity.Activities;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.guessthecelebrity.Data.CelebrityGameSQLOH;
import com.example.guessthecelebrity.ListFragments.ScoresListFragment;
import com.example.guessthecelebrity.R;

public class ScoresActivity extends AppCompatActivity {
	SQLiteDatabase db;
	SQLiteOpenHelper celebrityGameSQLOH;
	Cursor cursor;
	
	Button btnMenu;
	TextView highScore, avgScore;
	int avg = 0, high = 0;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_scores);
		
		initVariables();
		getScoresFromDatabase();
		updateScores();
		
	}
	
	private void initVariables() {
		this.highScore = findViewById(R.id.highScore);
		this.avgScore = findViewById(R.id.avgScore);
		this.btnMenu = findViewById(R.id.btnMainMenu);
		
		btnMenu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				Intent intent = new Intent(ScoresActivity.this, MainActivity.class);
				startActivity(intent);
			}
		});
		
	}
	
	private void updateScores() {
		
		this.highScore.setText(high + "");
		this.avgScore.setText(avg + "");
		
		ScoresListFragment scoresListFragment = new ScoresListFragment(cursor, db);
		FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
		ft.replace(R.id.scoresListFragment, scoresListFragment);
		ft.addToBackStack(null);
		ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
		ft.commit();
	}
	
	private void getScoresFromDatabase() {
		
		
		try {
			celebrityGameSQLOH = new CelebrityGameSQLOH(this);
			db = celebrityGameSQLOH.getReadableDatabase();
			cursor = db.query(
				CelebrityGameSQLOH.DB_TABLE_SCORE,
				
				new String[]{
					"_id",
					CelebrityGameSQLOH.DB_SCORE_NAME,
					CelebrityGameSQLOH.DB_SCORE_SCORE,
					CelebrityGameSQLOH.DB_SCORE_DATE,
				},
				null, null, null, null, "_id" + " DESC"
			);
			
			
			while (cursor.moveToNext()) {
				int score = cursor.getInt(2);
				avg += score;
				high = Math.max(score, high);
			}
			avg = cursor.getCount() > 0 ? avg / cursor.getCount() : avg;
		}
		catch (Exception e) {
			CelebrityGameSQLOH.showError(this);
		}
	}
	
}