package com.example.guessthecelebrity.Data;

public class QuestionPair {
	public Question question;
	public String answer;
	
	public QuestionPair(Question question, String answer) {
		this.question = question;
		this.answer = answer;
	}
}
