package com.example.guessthecelebrity.ListFragments;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.ListFragment;

import com.example.guessthecelebrity.Data.CelebrityGameSQLOH;
import com.example.guessthecelebrity.R;

public class ScoresListFragment extends ListFragment {
	Cursor cursor;
	SQLiteDatabase db;
	
	public ScoresListFragment(Cursor cursor, SQLiteDatabase db) {
		this.cursor = cursor;
		this.db = db;
	}
	
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
													 Bundle savedInstanceState) {
		
		loadScores(inflater);
		
		// return view;
	return super.onCreateView(inflater, container, savedInstanceState);
	}
	
	private void loadScores(LayoutInflater inflater) {
		Context context = inflater.getContext();
		
		try {
			CursorAdapter cursorAdapter = new SimpleCursorAdapter(
				context,
				R.layout.simple_list_score_item,
				cursor,
				new String[]{CelebrityGameSQLOH.DB_SCORE_NAME, CelebrityGameSQLOH.DB_SCORE_SCORE, CelebrityGameSQLOH.DB_SCORE_DATE},
				new int[]{R.id.txtName, R.id.txtScore, R.id.txtDate},
				0
			);
			
			setListAdapter(cursorAdapter);
		}
		catch (Exception e) {
			CelebrityGameSQLOH.showError(context);
		}
		
	}
}