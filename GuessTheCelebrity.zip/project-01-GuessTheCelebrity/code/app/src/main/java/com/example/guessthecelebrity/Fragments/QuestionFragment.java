package com.example.guessthecelebrity.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.guessthecelebrity.R;

public class QuestionFragment extends Fragment {
	
	private String name;
	private int imgResourceId;
	
	public QuestionFragment(String name, int imgResource) {
			this.name = name;
			this.imgResourceId = imgResource;
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
													 Bundle savedInstanceState) {
		// Inflate the layout for this fragment
		View view = inflater.inflate(R.layout.fragment_question, container, false);
		
		TextView txtCelebrityName = view.findViewById(R.id.txtCelebrityName);
		ImageView imgCelebrity = view.findViewById(R.id.imgCelebrity);
		
		txtCelebrityName.setText(name);
		imgCelebrity.setImageResource(imgResourceId);
		
		return  view;
	}
}