package com.example.guessthecelebrity.Data;

import androidx.annotation.NonNull;

public class Question {
	private String name;
	private int imgResourceID;
	
	public Question(String name, int imgResourceID) {
		this.name = name;
		this.imgResourceID = imgResourceID;
	}
	
	public String getName() {
		return name;
	}
	
	public int getImgResourceID() {
		return imgResourceID;
	}
	
	@NonNull @Override
	public String toString() {
		return this.name;
	}
}
